#!/usr/bin/env python
# -*- coding:utf-8 -*-

#Author:xp
#blog_url: http://blog.csdn.net/wuxingpu5/article/details/71209731

'''test File'''
dic={'name':'dev','passwd':'asdf'}
print(dic['name'])
if dic['name']=='dev':
    print('pass')