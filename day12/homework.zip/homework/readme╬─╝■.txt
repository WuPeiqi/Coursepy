助教老师好:
本次作业路径:homework/front/

chrome打开index.html即可,自动跳转第一个页面
1.第一个页面为login.html  点击注册或重置密码即可
2.注册页面为register.html
3.已补充重置密码页面repwd.html

4其余注册用户协议等链接已做基本页

blog地址:http://blog.csdn.net/wuxingpu5

谢谢